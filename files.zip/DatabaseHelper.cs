using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;

namespace MvolaKiosque
{
    // ============================================================
    //  DatabaseHelper.cs – MVola Kiosque
    //  Gère la connexion MySQL + toutes les opérations CRUD
    //  Nécessite le NuGet : MySql.Data
    // ============================================================

    public static class DB
    {
        // ── Paramètres de connexion ────────────────────────────
        private const string HOST    = "localhost";
        private const string DBNAME  = "mvola_kiosque";
        private const string USER    = "root";
        private const string PASS    = "";
        private const int    PORT    = 3306;

        private static string ConnectionString =>
            $"Server={HOST};Port={PORT};Database={DBNAME};Uid={USER};Pwd={PASS};Charset=utf8mb4;";

        // ── Test de connexion ──────────────────────────────────
        public static bool TestConnection(out string errMsg)
        {
            errMsg = "";
            try
            {
                using var con = new MySqlConnection(ConnectionString);
                con.Open();
                return true;
            }
            catch (Exception ex) { errMsg = ex.Message; return false; }
        }

        // ── Méthode générique d'exécution ──────────────────────
        private static MySqlConnection GetConnection() =>
            new MySqlConnection(ConnectionString);

        private static DataTable Query(string sql, params (string, object)[] prms)
        {
            var dt = new DataTable();
            using var con = GetConnection();
            con.Open();
            using var cmd = new MySqlCommand(sql, con);
            foreach (var (n, v) in prms) cmd.Parameters.AddWithValue(n, v ?? DBNull.Value);
            using var ada = new MySqlDataAdapter(cmd);
            ada.Fill(dt);
            return dt;
        }

        private static int Execute(string sql, params (string, object)[] prms)
        {
            using var con = GetConnection();
            con.Open();
            using var cmd = new MySqlCommand(sql, con);
            foreach (var (n, v) in prms) cmd.Parameters.AddWithValue(n, v ?? DBNull.Value);
            return cmd.ExecuteNonQuery();
        }

        private static long ExecuteInsert(string sql, params (string, object)[] prms)
        {
            using var con = GetConnection();
            con.Open();
            using var cmd = new MySqlCommand(sql, con);
            foreach (var (n, v) in prms) cmd.Parameters.AddWithValue(n, v ?? DBNull.Value);
            cmd.ExecuteNonQuery();
            return cmd.LastInsertedId;
        }

        // ════════════════════════════════════════════════════════
        //  CLIENTS
        // ════════════════════════════════════════════════════════
        public static DataTable GetClients() => Query(
            "SELECT id_client AS Id, nom_client AS Nom, prenom_client AS Prenom, " +
            "telephone_client AS Telephone, adresse_client AS Adresse, CIN " +
            "FROM CLIENT ORDER BY id_client");

        public static DataTable SearchClients(string term) => Query(
            "SELECT id_client AS Id, nom_client AS Nom, prenom_client AS Prenom, " +
            "telephone_client AS Telephone, adresse_client AS Adresse, CIN " +
            "FROM CLIENT WHERE nom_client LIKE @t OR telephone_client LIKE @t OR CIN LIKE @t " +
            "ORDER BY id_client",
            ("@t", $"%{term}%"));

        public static long SaveClient(int id, string nom, string prenom, string tel, string adr, string cin)
        {
            if (id > 0)
            {
                Execute("UPDATE CLIENT SET nom_client=@n,prenom_client=@p,telephone_client=@t," +
                        "adresse_client=@a,CIN=@c WHERE id_client=@id",
                        ("@n",nom),("@p",prenom),("@t",tel),("@a",adr),("@c",cin),("@id",id));
                return id;
            }
            return ExecuteInsert("INSERT INTO CLIENT(nom_client,prenom_client,telephone_client,adresse_client,CIN) " +
                                 "VALUES(@n,@p,@t,@a,@c)",
                                 ("@n",nom),("@p",prenom),("@t",tel),("@a",adr),("@c",cin));
        }

        public static void DeleteClient(int id) =>
            Execute("DELETE FROM CLIENT WHERE id_client=@id", ("@id", id));

        // ════════════════════════════════════════════════════════
        //  AGENTS
        // ════════════════════════════════════════════════════════
        public static DataTable GetAgents() => Query(
            "SELECT id_agent AS Id, nom_agent AS Nom, prenom_agent AS Prenom, " +
            "telephone_agent AS Telephone, email_agent AS Email " +
            "FROM AGENT ORDER BY id_agent");

        public static long SaveAgent(int id, string nom, string prenom, string tel, string email)
        {
            if (id > 0)
            {
                Execute("UPDATE AGENT SET nom_agent=@n,prenom_agent=@p,telephone_agent=@t," +
                        "email_agent=@e WHERE id_agent=@id",
                        ("@n",nom),("@p",prenom),("@t",tel),("@e",email),("@id",id));
                return id;
            }
            return ExecuteInsert("INSERT INTO AGENT(nom_agent,prenom_agent,telephone_agent,email_agent) " +
                                 "VALUES(@n,@p,@t,@e)",
                                 ("@n",nom),("@p",prenom),("@t",tel),("@e",email));
        }

        public static void DeleteAgent(int id) =>
            Execute("DELETE FROM AGENT WHERE id_agent=@id", ("@id", id));

        // ════════════════════════════════════════════════════════
        //  KIOSQUES
        // ════════════════════════════════════════════════════════
        public static DataTable GetKiosques() => Query(
            "SELECT id_kiosque AS Id, nom_kiosque AS Nom, adresse_kiosque AS Adresse, " +
            "date_ouverture AS DateOuverture FROM KIOSQUE ORDER BY id_kiosque");

        public static long SaveKiosque(int id, string nom, string adr, DateTime? date)
        {
            string d = date.HasValue ? date.Value.ToString("yyyy-MM-dd") : null;
            if (id > 0)
            {
                Execute("UPDATE KIOSQUE SET nom_kiosque=@n,adresse_kiosque=@a,date_ouverture=@d WHERE id_kiosque=@id",
                        ("@n",nom),("@a",adr),("@d",d),("@id",id));
                return id;
            }
            return ExecuteInsert("INSERT INTO KIOSQUE(nom_kiosque,adresse_kiosque,date_ouverture) VALUES(@n,@a,@d)",
                                 ("@n",nom),("@a",adr),("@d",d));
        }

        public static void DeleteKiosque(int id) =>
            Execute("DELETE FROM KIOSQUE WHERE id_kiosque=@id", ("@id", id));

        // ════════════════════════════════════════════════════════
        //  TRANSACTIONS
        // ════════════════════════════════════════════════════════
        public static DataTable GetTransactions() => Query(
            "SELECT id_transaction AS Id, type_transaction AS Type, montant AS Montant, " +
            "DATE_FORMAT(date_transaction,'%Y-%m-%d') AS Date, " +
            "compte_emetteur AS Emetteur, compte_recepteur AS Recepteur, " +
            "id_agent AS Agent FROM TRANSACTION ORDER BY id_transaction");

        public static DataTable FilterTransactions(string type, string compteSearch) => Query(
            "SELECT id_transaction AS Id, type_transaction AS Type, montant AS Montant, " +
            "DATE_FORMAT(date_transaction,'%Y-%m-%d') AS Date, " +
            "compte_emetteur AS Emetteur, compte_recepteur AS Recepteur, " +
            "id_agent AS Agent FROM TRANSACTION " +
            "WHERE (@type='' OR type_transaction=@type) " +
            "AND (@s='' OR compte_emetteur LIKE @s OR compte_recepteur LIKE @s) " +
            "ORDER BY id_transaction",
            ("@type", type), ("@s", string.IsNullOrEmpty(compteSearch) ? "" : $"%{compteSearch}%"));

        public static long SaveTransaction(int id, string type, decimal montant, string date,
                                           string emet, string recp, int agent)
        {
            if (id > 0)
            {
                Execute("UPDATE TRANSACTION SET type_transaction=@tp,montant=@m,date_transaction=@d," +
                        "compte_emetteur=@e,compte_recepteur=@r,id_agent=@ag WHERE id_transaction=@id",
                        ("@tp",type),("@m",montant),("@d",date),("@e",emet),("@r",recp),("@ag",agent),("@id",id));
                return id;
            }
            return ExecuteInsert("INSERT INTO TRANSACTION(type_transaction,montant,date_transaction," +
                                 "compte_emetteur,compte_recepteur,id_agent) VALUES(@tp,@m,@d,@e,@r,@ag)",
                                 ("@tp",type),("@m",montant),("@d",date),("@e",emet),("@r",recp),("@ag",agent));
        }

        public static void DeleteTransaction(int id) =>
            Execute("DELETE FROM TRANSACTION WHERE id_transaction=@id", ("@id", id));

        // ════════════════════════════════════════════════════════
        //  STATISTIQUES
        // ════════════════════════════════════════════════════════
        public static DataTable GetStats() => Query(
            "SELECT type_transaction AS Type, COUNT(*) AS NbOp, SUM(montant) AS TotalMontant " +
            "FROM TRANSACTION GROUP BY type_transaction ORDER BY NbOp DESC");

        public static DataTable GetSummary() => Query(
            "SELECT " +
            "(SELECT COUNT(*) FROM CLIENT) AS NbClients, " +
            "(SELECT COUNT(*) FROM AGENT)  AS NbAgents, " +
            "(SELECT COUNT(*) FROM KIOSQUE) AS NbKiosques, " +
            "(SELECT COUNT(*) FROM TRANSACTION) AS NbTrans, " +
            "(SELECT COALESCE(SUM(montant),0) FROM TRANSACTION) AS TotalMontant");
    }
}
