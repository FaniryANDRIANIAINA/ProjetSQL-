using System;
using System.Windows.Forms;

namespace MvolaKiosque
{
    // ============================================================
    //  Program.cs – Point d'entrée de l'application
    //  MVola Kiosque – Windows Forms C#
    // ============================================================
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // ── Vérifier la connexion BDD ──────────────────────
            if (!DB.TestConnection(out string dbErr))
            {
                var res = MessageBox.Show(
                    $"⚠️ Impossible de se connecter à la base de données MySQL.\n\n" +
                    $"Erreur : {dbErr}\n\n" +
                    $"Vérifiez que MySQL est démarré et que la BDD 'mvola_kiosque' existe.\n\n" +
                    $"Continuer quand même (mode hors-ligne) ?",
                    "Connexion BDD",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);
                if (res == DialogResult.No) return;
            }

            // ── Afficher le formulaire de connexion ────────────
            using var login = new LoginForm();
            if (login.ShowDialog() != DialogResult.OK) return;

            // ── Ouvrir le tableau de bord principal ────────────
            var main = new MainForm
            {
                AgentId  = login.AgentId,
                AgentNom = login.AgentNom
            };
            Application.Run(main);
        }
    }
}
