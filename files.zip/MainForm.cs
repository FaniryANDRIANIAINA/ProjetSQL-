using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace MvolaKiosque
{
    // ============================================================
    //  MainForm.cs – MVola Kiosque  (Windows Forms)
    //  Dashboard + Clients + Agents + Kiosques + Transactions
    //  + Statistiques + Impression
    // ============================================================
    public class MainForm : Form
    {
        // ── Session ────────────────────────────────────────────
        public int    AgentId  { get; set; }
        public string AgentNom { get; set; }

        // ── Couleurs thème MVola ───────────────────────────────
        private static readonly Color CYellow  = Color.FromArgb(245, 200, 0);
        private static readonly Color CBlue    = Color.FromArgb(26,  26,  94);
        private static readonly Color CGreen   = Color.FromArgb(26, 138,  0);
        private static readonly Color CGreenM  = Color.FromArgb(39, 174, 96);
        private static readonly Color CDark    = Color.FromArgb(13,  13, 26);
        private static readonly Color CGrayL   = Color.FromArgb(244, 246, 248);

        // ── Contrôles principaux ───────────────────────────────
        private Panel    pnlHeader, pnlSidebar, pnlContent;
        private Label    lblClock, lblAgent;
        private TabControl tabMain;
        private Timer    tmrClock;

        // ── Tab : Dashboard ────────────────────────────────────
        private Label lblNbClients, lblNbAgents, lblNbKiosques, lblNbTrans, lblTotalMnt;

        // ── Tab : Clients ──────────────────────────────────────
        private DataGridView dgvClients;
        private TextBox txtSearchClients;

        // ── Tab : Agents ───────────────────────────────────────
        private DataGridView dgvAgents;

        // ── Tab : Kiosques ─────────────────────────────────────
        private DataGridView dgvKiosques;

        // ── Tab : Transactions ─────────────────────────────────
        private DataGridView dgvTrans;
        private ComboBox cboFilterType;
        private TextBox  txtSearchTrans;

        // ── Tab : Stats ────────────────────────────────────────
        private DataGridView dgvStats;
        private Label lblStatsSummary;

        // ══════════════════════════════════════════════════════
        public MainForm()
        {
            InitializeComponent();
            LoadAll();
        }

        // ══════════════════════════════════════════════════════
        //  INIT UI
        // ══════════════════════════════════════════════════════
        private void InitializeComponent()
        {
            this.Text            = "MVola Kiosque – Gestion";
            this.Size            = new Size(1200, 750);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = CGrayL;
            this.Font            = new Font("Segoe UI", 9f);
            this.MinimumSize     = new Size(900, 600);

            BuildHeader();
            BuildSidebar();
            BuildContent();
            BuildTimer();
        }

        // ── Header ─────────────────────────────────────────────
        private void BuildHeader()
        {
            pnlHeader = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 58,
                BackColor = CBlue
            };

            var lblLogo = new Label
            {
                Text      = "MVola  yas",
                Font      = new Font("Segoe UI Black", 20f, FontStyle.Bold),
                ForeColor = CYellow,
                AutoSize  = true,
                Location  = new Point(16, 12)
            };

            var lblAppTitle = new Label
            {
                Text      = "SYSTÈME DE GESTION KIOSQUE",
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(160, 160, 220),
                AutoSize  = true,
                Location  = new Point(200, 20)
            };

            lblAgent = new Label
            {
                Text      = "Agent",
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize  = true,
                Location  = new Point(850, 12)
            };

            lblClock = new Label
            {
                Text      = "00:00:00",
                Font      = new Font("Segoe UI Mono", 14f, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 180, 220),
                AutoSize  = true,
                Location  = new Point(850, 28)
            };

            var btnLogout = new Button
            {
                Text      = "Déconnexion",
                Location  = new Point(1080, 14),
                Size      = new Size(100, 30),
                BackColor = Color.FromArgb(140, 30, 30),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += (s, e) =>
            {
                if (MessageBox.Show("Déconnecter et quitter ?", "Déconnexion",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    Application.Exit();
            };

            pnlHeader.Controls.AddRange(new Control[] { lblLogo, lblAppTitle, lblAgent, lblClock, btnLogout });
            this.Controls.Add(pnlHeader);
        }

        // ── Sidebar ────────────────────────────────────────────
        private void BuildSidebar()
        {
            pnlSidebar = new Panel
            {
                Dock      = DockStyle.Left,
                Width     = 0,   // masquée – on utilise TabControl
                BackColor = CBlue
            };
            this.Controls.Add(pnlSidebar);
        }

        // ── Contenu principal (TabControl) ─────────────────────
        private void BuildContent()
        {
            pnlContent = new Panel { Dock = DockStyle.Fill };
            this.Controls.Add(pnlContent);

            tabMain = new TabControl
            {
                Dock      = DockStyle.Fill,
                Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                DrawMode  = TabDrawMode.OwnerDrawFixed,
                ItemSize  = new Size(140, 36)
            };
            tabMain.DrawItem += TabMain_DrawItem;
            pnlContent.Controls.Add(tabMain);

            tabMain.TabPages.Add(BuildTabDashboard());
            tabMain.TabPages.Add(BuildTabClients());
            tabMain.TabPages.Add(BuildTabAgents());
            tabMain.TabPages.Add(BuildTabKiosques());
            tabMain.TabPages.Add(BuildTabTransactions());
            tabMain.TabPages.Add(BuildTabStats());
        }

        private void TabMain_DrawItem(object sender, DrawItemEventArgs e)
        {
            var tab = (TabControl)sender;
            string text = tab.TabPages[e.Index].Text;
            bool selected = e.Index == tab.SelectedIndex;
            e.Graphics.FillRectangle(new SolidBrush(selected ? CYellow : CBlue), e.Bounds);
            var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            e.Graphics.DrawString(text, new Font("Segoe UI", 8.5f, FontStyle.Bold),
                new SolidBrush(selected ? CDark : Color.FromArgb(180, 180, 230)), e.Bounds, sf);
        }

        // ── Timer horloge ──────────────────────────────────────
        private void BuildTimer()
        {
            tmrClock = new Timer { Interval = 1000, Enabled = true };
            tmrClock.Tick += (s, e) =>
                lblClock.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        // ══════════════════════════════════════════════════════
        //  TAB DASHBOARD
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabDashboard()
        {
            var tp = new TabPage("🏠  Dashboard") { BackColor = CGrayL, Padding = new Padding(20) };

            var pnlStats = new FlowLayoutPanel
            {
                Bounds      = new Rectangle(20, 20, 1100, 160),
                BackColor   = Color.Transparent,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents  = false
            };

            lblNbClients  = MakeStatCard(pnlStats, "👥", "0", "CLIENTS",  CYellow);
            lblNbAgents   = MakeStatCard(pnlStats, "👤", "0", "AGENTS",   CGreenM);
            lblNbKiosques = MakeStatCard(pnlStats, "🏪", "0", "KIOSQUES", Color.FromArgb(52, 100, 210));
            lblNbTrans    = MakeStatCard(pnlStats, "💳", "0", "TRANSACTIONS", CGreen);
            lblTotalMnt   = MakeStatCard(pnlStats, "💰", "—", "TOTAL Ar",  Color.FromArgb(180, 80, 0));

            tp.Controls.Add(pnlStats);

            // Boutons raccourcis
            var pnlQuick = new FlowLayoutPanel
            {
                Bounds        = new Rectangle(20, 190, 1100, 100),
                BackColor     = Color.Transparent,
                FlowDirection = FlowDirection.LeftToRight
            };
            string[] qLabels = {"+ Nouveau Client","+ Nouvel Agent","+ Nouveau Kiosque","+ Nouvelle Transaction","📊 Statistiques"};
            int[]    qTabs   = {1, 2, 3, 4, 5};
            for (int i = 0; i < qLabels.Length; i++)
            {
                int tabIdx = qTabs[i];
                var b = new Button
                {
                    Text      = qLabels[i],
                    Size      = new Size(195, 60),
                    Margin    = new Padding(4),
                    BackColor = CBlue,
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    Cursor    = Cursors.Hand
                };
                b.FlatAppearance.BorderColor = CYellow;
                b.FlatAppearance.BorderSize  = 1;
                b.Click += (s, e) =>
                {
                    tabMain.SelectedIndex = tabIdx;
                    if (tabIdx < 5) OpenAddDialog(tabIdx);
                };
                pnlQuick.Controls.Add(b);
            }
            tp.Controls.Add(pnlQuick);

            return tp;
        }

        private Label MakeStatCard(FlowLayoutPanel parent, string icon, string number, string label, Color accent)
        {
            var pnl = new Panel
            {
                Size      = new Size(200, 140),
                Margin    = new Padding(6),
                BackColor = Color.White
            };
            // Barre colorée en haut
            var bar = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = accent };
            var lblIco = new Label { Text = icon, Font = new Font("Segoe UI", 22f), AutoSize = true, Location = new Point(16, 12) };
            var lblNum = new Label { Text = number, Font = new Font("Segoe UI Black", 28f, FontStyle.Bold),
                                     ForeColor = CDark, AutoSize = true, Location = new Point(14, 45) };
            var lblLbl = new Label { Text = label, Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                                     ForeColor = Color.Gray, AutoSize = true, Location = new Point(16, 100) };
            pnl.Controls.AddRange(new Control[] { bar, lblIco, lblNum, lblLbl });
            parent.Controls.Add(pnl);
            return lblNum;
        }

        // ══════════════════════════════════════════════════════
        //  TAB CLIENTS
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabClients()
        {
            var tp = new TabPage("👥  Clients") { BackColor = CGrayL, Padding = new Padding(12) };

            var toolbar = MakeToolbar(tp, "Gestion des Clients");
            txtSearchClients = new TextBox
            {
                Location = new Point(400, 12), Size = new Size(220, 26),
                PlaceholderText = "🔍 Nom, téléphone, CIN..."
            };
            var btnSearch = MakeBtn("Rechercher", 630, 10);
            var btnNew    = MakeBtn("+ Nouveau",  720, 10, CYellow, CDark);
            toolbar.Controls.AddRange(new Control[] { txtSearchClients, btnSearch, btnNew });

            txtSearchClients.TextChanged += (s, e) => LoadClients();
            btnSearch.Click += (s, e) => LoadClients();
            btnNew.Click    += (s, e) => OpenClientDialog(0);

            dgvClients = MakeDgv();
            dgvClients.Bounds = new Rectangle(0, 50, 1150, 580);
            dgvClients.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0) OpenClientDialog(GetId(dgvClients, e.RowIndex));
            };
            tp.Controls.Add(dgvClients);
            return tp;
        }

        // ══════════════════════════════════════════════════════
        //  TAB AGENTS
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabAgents()
        {
            var tp = new TabPage("👤  Agents") { BackColor = CGrayL, Padding = new Padding(12) };
            var toolbar = MakeToolbar(tp, "Gestion des Agents");
            var btnNew = MakeBtn("+ Nouveau", 400, 10, CYellow, CDark);
            toolbar.Controls.Add(btnNew);
            btnNew.Click += (s, e) => OpenAgentDialog(0);

            dgvAgents = MakeDgv();
            dgvAgents.Bounds = new Rectangle(0, 50, 1150, 580);
            dgvAgents.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0) OpenAgentDialog(GetId(dgvAgents, e.RowIndex));
            };
            tp.Controls.Add(dgvAgents);
            return tp;
        }

        // ══════════════════════════════════════════════════════
        //  TAB KIOSQUES
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabKiosques()
        {
            var tp = new TabPage("🏪  Kiosques") { BackColor = CGrayL, Padding = new Padding(12) };
            var toolbar = MakeToolbar(tp, "Gestion des Kiosques");
            var btnNew = MakeBtn("+ Nouveau", 400, 10, CYellow, CDark);
            toolbar.Controls.Add(btnNew);
            btnNew.Click += (s, e) => OpenKiosqueDialog(0);

            dgvKiosques = MakeDgv();
            dgvKiosques.Bounds = new Rectangle(0, 50, 1150, 580);
            dgvKiosques.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0) OpenKiosqueDialog(GetId(dgvKiosques, e.RowIndex));
            };
            tp.Controls.Add(dgvKiosques);
            return tp;
        }

        // ══════════════════════════════════════════════════════
        //  TAB TRANSACTIONS
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabTransactions()
        {
            var tp = new TabPage("💳  Transactions") { BackColor = CGrayL, Padding = new Padding(12) };
            var toolbar = MakeToolbar(tp, "Transactions");

            cboFilterType = new ComboBox
            {
                Location = new Point(300, 12), Size = new Size(150, 26),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cboFilterType.Items.AddRange(new object[] { "Tous types", "DEPOT", "RETRAIT", "TRANSFERT", "2TOI ET MOI" });
            cboFilterType.SelectedIndex = 0;

            txtSearchTrans = new TextBox
            {
                Location = new Point(460, 12), Size = new Size(200, 26),
                PlaceholderText = "🔍 N° compte..."
            };
            var btnNew = MakeBtn("+ Nouveau", 670, 10, CYellow, CDark);
            toolbar.Controls.AddRange(new Control[] { cboFilterType, txtSearchTrans, btnNew });

            cboFilterType.SelectedIndexChanged += (s, e) => LoadTransactions();
            txtSearchTrans.TextChanged          += (s, e) => LoadTransactions();
            btnNew.Click                        += (s, e) => OpenTransactionDialog(0);

            dgvTrans = MakeDgv();
            dgvTrans.Bounds = new Rectangle(0, 50, 1150, 580);
            dgvTrans.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0) OpenTransactionDialog(GetId(dgvTrans, e.RowIndex));
            };
            tp.Controls.Add(dgvTrans);
            return tp;
        }

        // ══════════════════════════════════════════════════════
        //  TAB STATISTIQUES
        // ══════════════════════════════════════════════════════
        private TabPage BuildTabStats()
        {
            var tp = new TabPage("📊  Statistiques") { BackColor = CGrayL, Padding = new Padding(12) };

            var toolbar = MakeToolbar(tp, "Statistiques");
            var btnPrint = MakeBtn("🖨 Imprimer", 400, 10);
            toolbar.Controls.Add(btnPrint);
            btnPrint.Click += (s, e) => PrintStats();

            lblStatsSummary = new Label
            {
                Bounds    = new Rectangle(0, 55, 600, 28),
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = CDark,
                AutoSize  = false
            };
            tp.Controls.Add(lblStatsSummary);

            dgvStats = MakeDgv();
            dgvStats.Bounds = new Rectangle(0, 90, 600, 500);
            tp.Controls.Add(dgvStats);
            return tp;
        }

        // ══════════════════════════════════════════════════════
        //  CHARGEMENT DES DONNÉES
        // ══════════════════════════════════════════════════════
        private void LoadAll()
        {
            // Mettre à jour le nom de l'agent dans le header
            lblAgent.Text = $"👤  {AgentNom}";

            LoadDashboard();
            LoadClients();
            LoadAgents();
            LoadKiosques();
            LoadTransactions();
            LoadStats();
        }

        private void LoadDashboard()
        {
            try
            {
                var dt = DB.GetSummary();
                if (dt.Rows.Count > 0)
                {
                    var row = dt.Rows[0];
                    lblNbClients.Text  = row["NbClients"].ToString();
                    lblNbAgents.Text   = row["NbAgents"].ToString();
                    lblNbKiosques.Text = row["NbKiosques"].ToString();
                    lblNbTrans.Text    = row["NbTrans"].ToString();
                    decimal total = Convert.ToDecimal(row["TotalMontant"]);
                    lblTotalMnt.Text   = FormatAr(total);
                }
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        private void LoadClients()
        {
            try
            {
                string term = txtSearchClients?.Text ?? "";
                var dt = string.IsNullOrWhiteSpace(term) ? DB.GetClients() : DB.SearchClients(term);
                dgvClients.DataSource = dt;
                StyleDgv(dgvClients);
                AddActionColumn(dgvClients);
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        private void LoadAgents()
        {
            try { dgvAgents.DataSource = DB.GetAgents(); StyleDgv(dgvAgents); AddActionColumn(dgvAgents); }
            catch (Exception ex) { ShowDBError(ex); }
        }

        private void LoadKiosques()
        {
            try { dgvKiosques.DataSource = DB.GetKiosques(); StyleDgv(dgvKiosques); AddActionColumn(dgvKiosques); }
            catch (Exception ex) { ShowDBError(ex); }
        }

        private void LoadTransactions()
        {
            try
            {
                string type   = cboFilterType?.SelectedIndex > 0 ? cboFilterType.SelectedItem.ToString() : "";
                string search = txtSearchTrans?.Text ?? "";
                dgvTrans.DataSource = DB.FilterTransactions(type, search);
                StyleDgv(dgvTrans);
                ColorTransRows(dgvTrans);
                AddActionColumn(dgvTrans);
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        private void LoadStats()
        {
            try
            {
                dgvStats.DataSource = DB.GetStats();
                StyleDgv(dgvStats);
                var dt = DB.GetSummary();
                if (dt.Rows.Count > 0)
                {
                    decimal total = Convert.ToDecimal(dt.Rows[0]["TotalMontant"]);
                    int     nbTr  = Convert.ToInt32(dt.Rows[0]["NbTrans"]);
                    lblStatsSummary.Text = $"Total transactions : {nbTr}  |  Montant total : {FormatAr(total)}";
                }
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ══════════════════════════════════════════════════════
        //  DIALOGUES CRUD
        // ══════════════════════════════════════════════════════
        private void OpenAddDialog(int tabIdx)
        {
            switch (tabIdx)
            {
                case 1: OpenClientDialog(0); break;
                case 2: OpenAgentDialog(0); break;
                case 3: OpenKiosqueDialog(0); break;
                case 4: OpenTransactionDialog(0); break;
            }
        }

        // ── Client ─────────────────────────────────────────────
        private void OpenClientDialog(int id)
        {
            DataRow row = null;
            if (id > 0)
            {
                var dt = DB.GetClients();
                foreach (DataRow r in dt.Rows) if (Convert.ToInt32(r["Id"]) == id) { row = r; break; }
            }

            using var dlg = new CrudDialog("Client", id > 0 ? "Modifier Client" : "Nouveau Client",
                new[] { "Nom*", "Prénom", "Téléphone*", "Adresse", "CIN" },
                row == null ? null : new[] {
                    row["Nom"].ToString(), row["Prenom"].ToString(),
                    row["Telephone"].ToString(), row["Adresse"].ToString(), row["CIN"].ToString()
                });
            if (dlg.ShowDialog() != DialogResult.OK) return;
            var v = dlg.Values;
            if (string.IsNullOrWhiteSpace(v[0]) || string.IsNullOrWhiteSpace(v[2]))
            { MessageBox.Show("Nom et Téléphone obligatoires."); return; }
            try
            {
                DB.SaveClient(id, v[0], v[1], v[2], v[3], v[4]);
                LoadClients(); LoadDashboard();
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ── Agent ──────────────────────────────────────────────
        private void OpenAgentDialog(int id)
        {
            DataRow row = null;
            if (id > 0)
            {
                var dt = DB.GetAgents();
                foreach (DataRow r in dt.Rows) if (Convert.ToInt32(r["Id"]) == id) { row = r; break; }
            }
            using var dlg = new CrudDialog("Agent", id > 0 ? "Modifier Agent" : "Nouvel Agent",
                new[] { "Nom*", "Prénom", "Téléphone", "Email" },
                row == null ? null : new[] {
                    row["Nom"].ToString(), row["Prenom"].ToString(),
                    row["Telephone"].ToString(), row["Email"].ToString()
                });
            if (dlg.ShowDialog() != DialogResult.OK) return;
            var v = dlg.Values;
            if (string.IsNullOrWhiteSpace(v[0])) { MessageBox.Show("Nom obligatoire."); return; }
            try { DB.SaveAgent(id, v[0], v[1], v[2], v[3]); LoadAgents(); LoadDashboard(); }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ── Kiosque ────────────────────────────────────────────
        private void OpenKiosqueDialog(int id)
        {
            DataRow row = null;
            if (id > 0)
            {
                var dt = DB.GetKiosques();
                foreach (DataRow r in dt.Rows) if (Convert.ToInt32(r["Id"]) == id) { row = r; break; }
            }
            using var dlg = new CrudDialog("Kiosque", id > 0 ? "Modifier Kiosque" : "Nouveau Kiosque",
                new[] { "Nom*", "Adresse", "Date ouverture (YYYY-MM-DD)" },
                row == null ? null : new[] {
                    row["Nom"].ToString(), row["Adresse"].ToString(),
                    row["DateOuverture"].ToString()
                });
            if (dlg.ShowDialog() != DialogResult.OK) return;
            var v = dlg.Values;
            if (string.IsNullOrWhiteSpace(v[0])) { MessageBox.Show("Nom obligatoire."); return; }
            DateTime? date = DateTime.TryParse(v[2], out var d) ? d : (DateTime?)null;
            try { DB.SaveKiosque(id, v[0], v[1], date); LoadKiosques(); LoadDashboard(); }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ── Transaction ────────────────────────────────────────
        private void OpenTransactionDialog(int id)
        {
            DataRow row = null;
            if (id > 0)
            {
                var dt = DB.GetTransactions();
                foreach (DataRow r in dt.Rows) if (Convert.ToInt32(r["Id"]) == id) { row = r; break; }
            }
            using var dlg = new TransactionDialog(id, row);
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                DB.SaveTransaction(id, dlg.TypeTrans, dlg.Montant,
                    dlg.DateTrans, dlg.Emetteur, dlg.Recepteur, dlg.AgentId);
                LoadTransactions(); LoadDashboard();
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ── Supprimer ──────────────────────────────────────────
        private void DeleteRow(DataGridView dgv, string table)
        {
            if (dgv.CurrentRow == null) return;
            int id = GetId(dgv, dgv.CurrentRow.Index);
            if (id <= 0) return;
            if (MessageBox.Show($"Supprimer cet enregistrement (Id={id}) ?", "Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            try
            {
                switch (table)
                {
                    case "client":      DB.DeleteClient(id);      LoadClients();      break;
                    case "agent":       DB.DeleteAgent(id);       LoadAgents();       break;
                    case "kiosque":     DB.DeleteKiosque(id);     LoadKiosques();     break;
                    case "transaction": DB.DeleteTransaction(id); LoadTransactions(); break;
                }
                LoadDashboard();
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ══════════════════════════════════════════════════════
        //  IMPRESSION
        // ══════════════════════════════════════════════════════
        private void PrintStats()
        {
            try
            {
                var dt = DB.GetStats();
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("STATISTIQUES – MVola Kiosque");
                sb.AppendLine("============================");
                sb.AppendLine($"Imprimé le : {DateTime.Now:dd/MM/yyyy HH:mm}");
                sb.AppendLine();
                sb.AppendLine($"{"Type",-20} {"Nb op",-10} {"Montant total",20}");
                sb.AppendLine(new string('-', 52));
                foreach (DataRow r in dt.Rows)
                    sb.AppendLine($"{r["Type"],-20} {r["NbOp"],-10} {FormatAr(Convert.ToDecimal(r["TotalMontant"])),20}");

                var dlg = new PrintPreviewDialog();
                var pd  = new System.Drawing.Printing.PrintDocument();
                pd.PrintPage += (s, e) =>
                {
                    e.Graphics.DrawString(sb.ToString(), new Font("Courier New", 9f),
                        Brushes.Black, new PointF(40, 40));
                };
                dlg.Document = pd;
                dlg.ShowDialog();
            }
            catch (Exception ex) { ShowDBError(ex); }
        }

        // ══════════════════════════════════════════════════════
        //  HELPERS UI
        // ══════════════════════════════════════════════════════
        private Panel MakeToolbar(TabPage tp, string title)
        {
            var bar = new Panel
            {
                Bounds    = new Rectangle(0, 0, 1160, 44),
                BackColor = Color.White
            };
            var lbl = new Label
            {
                Text     = title,
                Font     = new Font("Segoe UI Black", 11f, FontStyle.Bold),
                ForeColor = CBlue,
                AutoSize  = true,
                Location  = new Point(10, 12)
            };
            bar.Controls.Add(lbl);
            tp.Controls.Add(bar);
            return bar;
        }

        private Button MakeBtn(string text, int x, int y, Color? bg = null, Color? fg = null)
        {
            var b = new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(110, 28),
                BackColor = bg ?? CBlue,
                ForeColor = fg ?? Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private DataGridView MakeDgv()
        {
            var dgv = new DataGridView
            {
                AllowUserToAddRows    = false,
                AllowUserToDeleteRows = false,
                ReadOnly              = true,
                AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor       = Color.White,
                BorderStyle           = BorderStyle.None,
                RowHeadersVisible     = false,
                Font                  = new Font("Segoe UI", 9f)
            };
            return dgv;
        }

        private void StyleDgv(DataGridView dgv)
        {
            dgv.ColumnHeadersDefaultCellStyle.BackColor  = CBlue;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor  = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font       = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(250, 252, 255);
            dgv.DefaultCellStyle.SelectionBackColor       = Color.FromArgb(230, 220, 180);
            dgv.DefaultCellStyle.SelectionForeColor       = CDark;
        }

        private void AddActionColumn(DataGridView dgv)
        {
            // Supprimer l'ancienne colonne action si elle existe
            if (dgv.Columns.Contains("ActionCol")) dgv.Columns.Remove("ActionCol");
            var col = new DataGridViewButtonColumn
            {
                Name        = "ActionCol",
                HeaderText  = "Actions",
                Text        = "🗑 Supprimer",
                UseColumnTextForButtonValue = true,
                Width       = 110
            };
            dgv.Columns.Add(col);
            dgv.CellClick -= Dgv_CellClickDelete;
            dgv.CellClick += Dgv_CellClickDelete;
        }

        private void Dgv_CellClickDelete(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var dgv = (DataGridView)sender;
            if (dgv.Columns[e.ColumnIndex].Name != "ActionCol") return;

            string table = "";
            if (dgv == dgvClients)  table = "client";
            else if (dgv == dgvAgents) table = "agent";
            else if (dgv == dgvKiosques) table = "kiosque";
            else if (dgv == dgvTrans)   table = "transaction";

            DeleteRow(dgv, table);
        }

        private void ColorTransRows(DataGridView dgv)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                string type = row.Cells["Type"]?.Value?.ToString() ?? "";
                row.DefaultCellStyle.BackColor = type switch
                {
                    "DEPOT"     => Color.FromArgb(232, 245, 233),
                    "RETRAIT"   => Color.FromArgb(255, 243, 224),
                    "TRANSFERT" => Color.FromArgb(227, 242, 253),
                    _           => Color.FromArgb(252, 228, 236)
                };
            }
        }

        private int GetId(DataGridView dgv, int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= dgv.Rows.Count) return 0;
            var cell = dgv.Rows[rowIndex].Cells["Id"];
            return cell != null ? Convert.ToInt32(cell.Value) : 0;
        }

        private string FormatAr(decimal amount) =>
            $"{amount:#,##0} Ar".Replace(",", " ");

        private void ShowDBError(Exception ex) =>
            MessageBox.Show($"Erreur base de données :\n{ex.Message}", "Erreur",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
