# MVola Kiosque – C# Windows Forms
## Guide d'installation dans Visual Studio

---

## 📁 Fichiers du projet
| Fichier | Rôle |
|---|---|
| `Program.cs` | Point d'entrée – vérifie BDD puis ouvre Login |
| `LoginForm.cs` | Formulaire de connexion (ID Agent + Code) |
| `MainForm.cs` | Interface principale : Dashboard + tous les onglets |
| `Dialogs.cs` | Dialogues CRUD (CrudDialog + TransactionDialog) |
| `DatabaseHelper.cs` | Toutes les requêtes MySQL (DB.cs) |

---

## 🚀 Étapes dans Visual Studio

### 1. Créer le projet
1. `Fichier` → `Nouveau` → `Projet`
2. Choisir **Application Windows Forms (.NET Framework)** ou **.NET 6/8**
3. Nom : `MvolaKiosque`
4. Supprimer les fichiers générés par défaut (`Form1.cs`, `Form1.Designer.cs`)

### 2. Ajouter les fichiers
Copier les 5 fichiers `.cs` dans le dossier du projet, puis :
- Clic droit sur le projet → `Ajouter` → `Élément existant...`
- Sélectionner tous les fichiers `.cs`

### 3. Installer le NuGet MySql.Data
1. Clic droit sur le projet → `Gérer les packages NuGet`
2. Rechercher : `MySql.Data`
3. Installer la version **8.x.x** (Oracle)

### 4. Configurer la connexion MySQL
Dans `DatabaseHelper.cs`, modifier ces constantes :
```csharp
private const string HOST   = "localhost";   // adresse du serveur MySQL
private const string DBNAME = "mvola_kiosque"; // nom de la base
private const string USER   = "root";
private const string PASS   = "";            // votre mot de passe MySQL
private const int    PORT   = 3306;
```

### 5. Créer la base de données MySQL
Exécuter ce script SQL dans phpMyAdmin ou MySQL Workbench :
```sql
CREATE DATABASE IF NOT EXISTS mvola_kiosque CHARACTER SET utf8mb4;
USE mvola_kiosque;

CREATE TABLE AGENT (
  id_agent       INT AUTO_INCREMENT PRIMARY KEY,
  nom_agent      VARCHAR(100) NOT NULL,
  prenom_agent   VARCHAR(100),
  telephone_agent VARCHAR(20),
  email_agent    VARCHAR(100)
);

CREATE TABLE CLIENT (
  id_client       INT AUTO_INCREMENT PRIMARY KEY,
  nom_client      VARCHAR(100) NOT NULL,
  prenom_client   VARCHAR(100),
  telephone_client VARCHAR(20),
  adresse_client  VARCHAR(200),
  CIN             VARCHAR(30)
);

CREATE TABLE KIOSQUE (
  id_kiosque      INT AUTO_INCREMENT PRIMARY KEY,
  nom_kiosque     VARCHAR(100) NOT NULL,
  adresse_kiosque VARCHAR(200),
  date_ouverture  DATE
);

CREATE TABLE TRANSACTION (
  id_transaction   INT AUTO_INCREMENT PRIMARY KEY,
  type_transaction VARCHAR(30) NOT NULL,
  montant          DECIMAL(15,2) NOT NULL,
  date_transaction DATE,
  compte_emetteur  VARCHAR(50),
  compte_recepteur VARCHAR(50),
  id_agent         INT,
  FOREIGN KEY (id_agent) REFERENCES AGENT(id_agent)
);

-- Données de test
INSERT INTO AGENT VALUES
(1,'Rakotoarivelo','Hery','034 00 000 01','hery@mvola.mg'),
(2,'Andriambelo','Sitraka','034 00 000 02','sitraka@mvola.mg'),
(3,'Razafindrakoto','Fanja','034 00 000 03','fanja@mvola.mg');
```

### 6. Lancer l'application
- `F5` ou `Ctrl+F5`
- Codes de connexion : Agent 1 → `1234`, Agent 2 → `2222`, etc.

---

## 🔧 Structure de l'application
```
LoginForm  →  (connexion réussie)  →  MainForm
                                         ├─ Dashboard  (stats globales)
                                         ├─ Clients    (CRUD + recherche)
                                         ├─ Agents     (CRUD)
                                         ├─ Kiosques   (CRUD)
                                         ├─ Transactions (CRUD + filtres)
                                         └─ Statistiques (+ impression)
```

---

## ⚠️ Notes importantes
- Double-clic sur une ligne du tableau → ouvre le dialogue de modification
- Bouton `🗑 Supprimer` sur chaque ligne → suppression avec confirmation
- Si MySQL n'est pas démarré, l'app propose de continuer en "mode hors-ligne"
- Le timeout de session PHP (2h) est remplacé ici par la fermeture de la fenêtre

---

*MVola Kiosque – Application de gestion  |  yas*
