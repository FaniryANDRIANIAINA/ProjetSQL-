using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MvolaKiosque
{
    public class LoginForm : Form
    {
        // ── Contrôles ──────────────────────────────────────────
        private Panel pnlHeader;
        private Label lblLogo, lblSub, lblYas;
        private Label lblTitle;
        private Label lblIdAgent, lblCode;
        private NumericUpDown numIdAgent;
        private TextBox txtCode;
        private Button btnTogglePw, btnLogin;
        private Label lblError;
        private Panel pnlHint;
        private Label lblHintTitle;
        private FlowLayoutPanel flpCodes;

        // Codes d'accès par défaut
        private readonly Dictionary<int, string> _codes = new Dictionary<int, string>
        {
            {1,"1234"},{2,"2222"},{3,"3333"},{4,"4444"},{5,"5555"}
        };
        private readonly Dictionary<int, string> _noms = new Dictionary<int, string>
        {
            {1,"Rakotoarivelo Hery"},{2,"Andriambelo Sitraka"},
            {3,"Razafindrakoto Fanja"},{4,"Ratovosoa Manda"},{5,"Ranoromalala Tiana"}
        };

        public int AgentId   { get; private set; }
        public string AgentNom { get; private set; }

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // ── Fenêtre ────────────────────────────────────────
            this.Text            = "MVola Kiosque – Connexion";
            this.Size            = new Size(440, 680);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.BackColor       = Color.FromArgb(13, 13, 26);
            this.Font            = new Font("Segoe UI", 9f);

            // ── Header ─────────────────────────────────────────
            pnlHeader = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 130,
                BackColor = Color.FromArgb(26, 26, 94)
            };

            lblLogo = new Label
            {
                Text      = "MVola",
                Font      = new Font("Segoe UI Black", 36f, FontStyle.Bold),
                ForeColor = Color.FromArgb(245, 200, 0),
                AutoSize  = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds    = new Rectangle(0, 20, 440, 55)
            };

            lblSub = new Label
            {
                Text      = "SYSTÈME DE GESTION KIOSQUE",
                Font      = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = Color.FromArgb(120, 120, 180),
                AutoSize  = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds    = new Rectangle(0, 75, 440, 20)
            };

            lblYas = new Label
            {
                Text      = " yas ",
                Font      = new Font("Segoe UI Black", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(13, 13, 26),
                BackColor = Color.FromArgb(245, 200, 0),
                AutoSize  = true,
                Location  = new Point(185, 100)
            };

            pnlHeader.Controls.AddRange(new Control[] { lblLogo, lblSub, lblYas });
            this.Controls.Add(pnlHeader);

            // ── Titre formulaire ───────────────────────────────
            lblTitle = new Label
            {
                Text      = "— ACCÈS SÉCURISÉ —",
                Font      = new Font("Segoe UI Black", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(245, 200, 0),
                AutoSize  = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds    = new Rectangle(20, 145, 400, 28)
            };
            this.Controls.Add(lblTitle);

            // ── Label + champ ID Agent ─────────────────────────
            lblIdAgent = MakeLabel("ID AGENT", 145, 185);
            numIdAgent = new NumericUpDown
            {
                Bounds    = new Rectangle(20, 205, 400, 36),
                Minimum   = 1,
                Maximum   = 999,
                BackColor = Color.FromArgb(30, 30, 50),
                ForeColor = Color.White,
                Font      = new Font("Segoe UI", 11f),
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.AddRange(new Control[] { lblIdAgent, numIdAgent });

            // ── Label + champ Code ─────────────────────────────
            lblCode = MakeLabel("CODE D'ACCÈS", 145, 255);
            txtCode = new TextBox
            {
                Bounds        = new Rectangle(20, 275, 360, 36),
                PasswordChar  = '●',
                BackColor     = Color.FromArgb(30, 30, 50),
                ForeColor     = Color.White,
                Font          = new Font("Segoe UI", 11f),
                BorderStyle   = BorderStyle.FixedSingle,
                MaxLength     = 10
            };
            txtCode.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) DoLogin(); };

            btnTogglePw = new Button
            {
                Text      = "👁",
                Bounds    = new Rectangle(382, 275, 38, 36),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(40, 40, 70),
                ForeColor = Color.FromArgb(180, 180, 220),
                Font      = new Font("Segoe UI", 10f),
                Cursor    = Cursors.Hand
            };
            btnTogglePw.FlatAppearance.BorderSize = 0;
            btnTogglePw.Click += (s, e) =>
            {
                txtCode.PasswordChar = (txtCode.PasswordChar == '●') ? '\0' : '●';
                btnTogglePw.Text = (txtCode.PasswordChar == '\0') ? "🙈" : "👁";
            };
            this.Controls.AddRange(new Control[] { lblCode, txtCode, btnTogglePw });

            // ── Message erreur ─────────────────────────────────
            lblError = new Label
            {
                Text      = "",
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 100, 100),
                BackColor = Color.FromArgb(80, 20, 20),
                AutoSize  = false,
                Bounds    = new Rectangle(20, 320, 400, 0),
                Padding   = new Padding(8),
                Visible   = false
            };
            this.Controls.Add(lblError);

            // ── Bouton Se connecter ────────────────────────────
            btnLogin = new Button
            {
                Text      = "🔑  SE CONNECTER",
                Bounds    = new Rectangle(20, 340, 400, 46),
                BackColor = Color.FromArgb(245, 200, 0),
                ForeColor = Color.FromArgb(13, 13, 26),
                Font      = new Font("Segoe UI Black", 11f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor    = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += (s, e) => DoLogin();
            this.Controls.Add(btnLogin);

            // ── Hints codes d'accès ────────────────────────────
            pnlHint = new Panel
            {
                Bounds    = new Rectangle(20, 400, 400, 190),
                BackColor = Color.FromArgb(20, 40, 20),
                BorderStyle = BorderStyle.FixedSingle
            };

            lblHintTitle = new Label
            {
                Text      = "🔑 Codes d'accès — cliquez pour remplir",
                Font      = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = Color.FromArgb(120, 180, 120),
                Bounds    = new Rectangle(8, 8, 380, 20)
            };
            pnlHint.Controls.Add(lblHintTitle);

            flpCodes = new FlowLayoutPanel
            {
                Bounds    = new Rectangle(8, 32, 382, 150),
                BackColor = Color.Transparent
            };

            foreach (var kv in _codes)
            {
                int agId   = kv.Key;
                string agCode = kv.Value;
                var btn = new Button
                {
                    Text      = $"Agent {agId}  →  {agCode}",
                    Width     = 116,
                    Height    = 32,
                    Margin    = new Padding(2),
                    BackColor = Color.FromArgb(30, 50, 30),
                    ForeColor = Color.FromArgb(200, 200, 200),
                    Font      = new Font("Segoe UI", 8f),
                    FlatStyle = FlatStyle.Flat,
                    Cursor    = Cursors.Hand,
                    Tag       = new KeyValuePair<int,string>(agId, agCode)
                };
                btn.FlatAppearance.BorderColor = Color.FromArgb(50, 90, 50);
                btn.Click += (s, e) =>
                {
                    var pair = (KeyValuePair<int,string>)((Button)s).Tag;
                    numIdAgent.Value = pair.Key;
                    txtCode.Text     = pair.Value;
                };
                flpCodes.Controls.Add(btn);
            }
            pnlHint.Controls.Add(flpCodes);
            this.Controls.Add(pnlHint);

            // ── Footer ─────────────────────────────────────────
            var lblFooter = new Label
            {
                Text      = "© 2025 MVola Kiosque — Application de gestion  |  yas",
                Font      = new Font("Segoe UI", 7f),
                ForeColor = Color.FromArgb(70, 70, 100),
                AutoSize  = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds    = new Rectangle(0, 610, 440, 28)
            };
            this.Controls.Add(lblFooter);
        }

        // ── Helpers ────────────────────────────────────────────
        private Label MakeLabel(string text, int timeout, int y)
        {
            return new Label
            {
                Text      = text,
                Font      = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(130, 130, 180),
                AutoSize  = false,
                Bounds    = new Rectangle(20, y, 300, 18)
            };
        }

        private void ShowError(string msg)
        {
            lblError.Text    = msg;
            lblError.Visible = true;
            lblError.Height  = 34;
            // Décaler les contrôles en dessous
            btnLogin.Top = 340 + 40;
            pnlHint.Top  = 400 + 40;
        }

        private void HideError()
        {
            lblError.Visible = false;
            lblError.Height  = 0;
            btnLogin.Top = 340;
            pnlHint.Top  = 400;
        }

        private void DoLogin()
        {
            HideError();
            int id     = (int)numIdAgent.Value;
            string code = txtCode.Text.Trim();

            if (code == "")
            {
                ShowError("⚠️ Saisissez votre ID Agent et votre code.");
                return;
            }
            if (!_codes.ContainsKey(id))
            {
                ShowError("❌ Agent introuvable. Vérifiez votre ID.");
                return;
            }
            if (_codes[id] != code)
            {
                ShowError("❌ Code d'accès incorrect. Réessayez.");
                return;
            }

            AgentId  = id;
            AgentNom = _noms.ContainsKey(id) ? _noms[id] : $"Agent {id}";
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
