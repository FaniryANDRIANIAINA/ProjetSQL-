using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace MvolaKiosque
{
    // ============================================================
    //  CrudDialog.cs – Dialogue générique Add/Edit
    //  Utilisé pour Clients, Agents, Kiosques
    // ============================================================
    public class CrudDialog : Form
    {
        private TextBox[] _fields;
        public  string[]  Values => Array.ConvertAll(_fields, f => f.Text.Trim());

        public CrudDialog(string entity, string title, string[] labels, string[] defaults = null)
        {
            this.Text            = title;
            this.Size            = new Size(420, labels.Length * 68 + 140);
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.FromArgb(244, 246, 248);
            this.Font            = new Font("Segoe UI", 9.5f);

            // Header coloré
            var hdr = new Panel { Dock = DockStyle.Top, Height = 44, BackColor = Color.FromArgb(26, 26, 94) };
            var lbl = new Label { Text = title, Font = new Font("Segoe UI Black", 11f, FontStyle.Bold),
                                  ForeColor = Color.FromArgb(245, 200, 0), AutoSize = true, Location = new Point(14, 10) };
            hdr.Controls.Add(lbl);
            this.Controls.Add(hdr);

            _fields = new TextBox[labels.Length];
            int y = 58;
            for (int i = 0; i < labels.Length; i++)
            {
                var lblF = new Label { Text = labels[i], Location = new Point(20, y), AutoSize = true,
                                       ForeColor = Color.FromArgb(80, 80, 120), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) };
                var txt  = new TextBox { Location = new Point(20, y + 20), Size = new Size(360, 28),
                                         BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10f) };
                if (defaults != null && i < defaults.Length) txt.Text = defaults[i];
                _fields[i] = txt;
                this.Controls.AddRange(new Control[] { lblF, txt });
                y += 62;
            }

            var btnOk = new Button
            {
                Text = "✔  Enregistrer", Location = new Point(20, y + 8), Size = new Size(170, 36),
                BackColor = Color.FromArgb(26, 138, 0), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand, DialogResult = DialogResult.OK
            };
            btnOk.FlatAppearance.BorderSize = 0;

            var btnCancel = new Button
            {
                Text = "✖  Annuler", Location = new Point(210, y + 8), Size = new Size(170, 36),
                BackColor = Color.FromArgb(160, 40, 40), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand, DialogResult = DialogResult.Cancel
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            this.Controls.AddRange(new Control[] { btnOk, btnCancel });
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
            this.Height = y + 80;
        }
    }

    // ============================================================
    //  TransactionDialog.cs – Dialogue spécialisé Transaction
    //  Avec ComboBox type + DateTimePicker + champs compte
    // ============================================================
    public class TransactionDialog : Form
    {
        public string  TypeTrans  { get; private set; }
        public decimal Montant    { get; private set; }
        public string  DateTrans  { get; private set; }
        public string  Emetteur   { get; private set; }
        public string  Recepteur  { get; private set; }
        public int     AgentId    { get; private set; }

        private ComboBox   cboType;
        private TextBox    txtMontant, txtEmet, txtRecp;
        private DateTimePicker dtpDate;
        private ComboBox   cboAgent;

        public TransactionDialog(int id, DataRow row = null)
        {
            this.Text            = id > 0 ? "Modifier Transaction" : "Nouvelle Transaction";
            this.Size            = new Size(420, 500);
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.FromArgb(244, 246, 248);
            this.Font            = new Font("Segoe UI", 9.5f);

            var hdr = new Panel { Dock = DockStyle.Top, Height = 44, BackColor = Color.FromArgb(26, 26, 94) };
            var lblH = new Label { Text = this.Text, Font = new Font("Segoe UI Black", 11f, FontStyle.Bold),
                                   ForeColor = Color.FromArgb(245, 200, 0), AutoSize = true, Location = new Point(14, 10) };
            hdr.Controls.Add(lblH);
            this.Controls.Add(hdr);

            int y = 56;

            // Type
            AddLabel("Type de transaction *", 20, y);
            cboType = new ComboBox { Location = new Point(20, y + 20), Size = new Size(360, 28),
                                     DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10f) };
            cboType.Items.AddRange(new object[] { "DEPOT", "RETRAIT", "TRANSFERT", "2TOI ET MOI" });
            cboType.SelectedIndex = 0;
            this.Controls.Add(cboType);
            y += 60;

            // Montant
            AddLabel("Montant (Ar) *", 20, y);
            txtMontant = AddTextBox(20, y + 20);
            y += 60;

            // Date
            AddLabel("Date", 20, y);
            dtpDate = new DateTimePicker { Location = new Point(20, y + 20), Size = new Size(360, 28),
                                           Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 10f),
                                           Value  = DateTime.Today };
            this.Controls.Add(dtpDate);
            y += 60;

            // Émetteur
            AddLabel("Compte émetteur", 20, y);
            txtEmet = AddTextBox(20, y + 20);
            y += 60;

            // Récepteur
            AddLabel("Compte récepteur", 20, y);
            txtRecp = AddTextBox(20, y + 20);
            y += 60;

            // Agent
            AddLabel("Agent", 20, y);
            cboAgent = new ComboBox { Location = new Point(20, y + 20), Size = new Size(360, 28),
                                      DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10f) };
            try
            {
                var agents = DB.GetAgents();
                foreach (DataRow r in agents.Rows)
                    cboAgent.Items.Add(new AgentItem(Convert.ToInt32(r["Id"]), $"{r["Id"]} – {r["Nom"]}"));
                if (cboAgent.Items.Count > 0) cboAgent.SelectedIndex = 0;
            }
            catch { cboAgent.Items.Add(new AgentItem(1, "Agent 1")); cboAgent.SelectedIndex = 0; }
            this.Controls.Add(cboAgent);
            y += 60;

            // Remplir si modification
            if (row != null)
            {
                string tp = row["Type"].ToString();
                for (int i = 0; i < cboType.Items.Count; i++)
                    if (cboType.Items[i].ToString() == tp) { cboType.SelectedIndex = i; break; }
                txtMontant.Text = row["Montant"].ToString();
                if (DateTime.TryParse(row["Date"].ToString(), out var d)) dtpDate.Value = d;
                txtEmet.Text = row["Emetteur"].ToString();
                txtRecp.Text = row["Recepteur"].ToString();
                int agId = Convert.ToInt32(row["Agent"]);
                for (int i = 0; i < cboAgent.Items.Count; i++)
                    if (((AgentItem)cboAgent.Items[i]).Id == agId) { cboAgent.SelectedIndex = i; break; }
            }

            var btnOk = new Button
            {
                Text = "✔  Enregistrer", Location = new Point(20, y + 8), Size = new Size(170, 36),
                BackColor = Color.FromArgb(26, 138, 0), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += BtnOk_Click;

            var btnCancel = new Button
            {
                Text = "✖  Annuler", Location = new Point(210, y + 8), Size = new Size(170, 36),
                BackColor = Color.FromArgb(160, 40, 40), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand, DialogResult = DialogResult.Cancel
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            this.Controls.AddRange(new Control[] { btnOk, btnCancel });
            this.CancelButton = btnCancel;
            this.Height = y + 80;
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (cboType.SelectedIndex < 0) { MessageBox.Show("Choisissez un type."); return; }
            if (!decimal.TryParse(txtMontant.Text.Trim(), out decimal m) || m <= 0)
            { MessageBox.Show("Montant invalide."); return; }
            TypeTrans = cboType.SelectedItem.ToString();
            Montant   = m;
            DateTrans = dtpDate.Value.ToString("yyyy-MM-dd");
            Emetteur  = txtEmet.Text.Trim();
            Recepteur = txtRecp.Text.Trim();
            AgentId   = cboAgent.SelectedIndex >= 0 ? ((AgentItem)cboAgent.SelectedItem).Id : 1;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void AddLabel(string text, int x, int y)
        {
            this.Controls.Add(new Label { Text = text, Location = new Point(x, y), AutoSize = true,
                ForeColor = Color.FromArgb(80, 80, 120), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) });
        }

        private TextBox AddTextBox(int x, int y)
        {
            var tb = new TextBox { Location = new Point(x, y), Size = new Size(360, 28),
                                   BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10f) };
            this.Controls.Add(tb);
            return tb;
        }

        private class AgentItem
        {
            public int    Id   { get; }
            public string Name { get; }
            public AgentItem(int id, string name) { Id = id; Name = name; }
            public override string ToString() => Name;
        }
    }
}
